﻿using System;
using System.ComponentModel.DataAnnotations;

namespace WebAppUser.Models
{
    public class User
    {
        [Key]
        public Guid Id { get; set; }
        [Required]
        [MaxLength(50, ErrorMessage ="EXCEEDING 50 CHARACTRERS")]
        public string FirstName { get; set; }
        [Required]
        [MaxLength(50, ErrorMessage = "EXCEEDING 50 CHARACTRERS")]
        public string LastName { get; set; }
        [Required]
       // [MaxLength(20, ErrorMessage = "")]
        public string Email { get; set; }
        [Required]
        [MaxLength(50, ErrorMessage = "PASSWORD SHOULD NOT EXCEED 50")]
        public string Password { get; set; }
    }
}
