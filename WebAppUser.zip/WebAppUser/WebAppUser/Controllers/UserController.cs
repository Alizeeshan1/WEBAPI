﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using WebAppUser.Models;
using WebAppUser.UserData;

namespace WebAppUser.Controllers
{   
    [ApiController]
    public class UserController : ControllerBase
    {
        private IUserData _userData;
        public UserController(IUserData userData)
        {
            _userData = userData;
        }

        [HttpGet]
        [Route("api/User")]
        public IActionResult GetUsers()
        {
            return Ok( _userData.GetUsers());
        }

        [HttpGet]
        [Route("api/User/{id}")]
        public IActionResult GetUser(Guid id)
        {
             var user = _userData.GetUser(id);
             if (User != null)
             {
                 return Ok( User);  
             }
               
             return NotFound($"User with Id:{id} was not found");
        }

        [HttpPost]
        [Route("api/User")]
        public IActionResult GetUser(User user)
        {
            _userData.AddUser(user);
            if (User != null)
            {
                return Ok(User);
            }

            return Created(HttpContext.Request.Scheme + "://" + HttpContext.Request.Host + HttpContext.Request.Path + "./" + user.Id, user);
        }

        [HttpDelete]
        [Route("api/User/{id}")]
        public IActionResult DeleteUser(Guid id)
        {
            var user = _userData.GetUser(id);
            if (user !=null)
            {
                _userData.DeleteUser(user);
                return Ok();
            }
            return NotFound($"NO User Found");
        }

        [HttpPatch]
        [Route("api/User/{id}")]
        public IActionResult EditUser(Guid id, User user)
        {
            var existuser = _userData.GetUser(id);
            if (existuser != null)
            {
                user.Id = existuser.Id;
                _userData.EditUser(user);
                return Ok();
                
            }
           // return Ok(user);
            return NotFound($"NO User Found");
        }
    }
}
