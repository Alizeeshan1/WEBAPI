﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using WebAppUser.Models;

namespace WebAppUser.UserData
{
    public class UserService : IUserData
    {
        private UserContext _context;
        public UserService(UserContext context)
        {
            _context = context;
        }
        public User AddUser(User user)
        {
            user.Id = Guid.NewGuid();
            _context.Users.Add(user);
            _context.SaveChanges();
            return user;
        }

        public User DeleteUser(User user)
        {
            _context.Users.Remove(user);
            _context.SaveChanges();
            return user;
        }
        
        public User EditUser(User user)
        {
            var existuser = _context.Users.Find(user.Id);
            if (existuser != null)
            {                
                existuser.FirstName = user.FirstName;
                existuser.LastName = user.LastName;
                existuser.Email = user.Email;
                existuser.Password = user.Password;
                _context.Users.Update(existuser);
                _context.SaveChanges();
             }
            return user;
        }

        public User GetUser(Guid Id)
        {
            var user =  _context.Users.Find(Id);
            return user;
        }

        public List<User> GetUsers()
        {
            return _context.Users.ToList();
        }
    }
}
