﻿using System;
using System.Collections.Generic;
using WebAppUser.Models;

namespace WebAppUser.UserData
{
    public interface IUserData
    {
        List<User> GetUsers();
        User GetUser(Guid Id);
        User AddUser(User user);
        User DeleteUser(User user);
        User EditUser(User user);
    }
}
